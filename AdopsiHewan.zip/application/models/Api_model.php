<?php
class Api_model extends CI_Model {

    public function getUsers() {
        return $this->db->get('users')->result();
    }

    public function login($email, $password) {
        return $this->db->get_where('users', [
            'email' => $email,
            'password' => $password
        ])->row();
    }
}
